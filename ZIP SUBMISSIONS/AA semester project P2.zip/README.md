# CS417 SPRING 2025 -- Asia Acosta

## Semester Project Langauge Selection: Python </br>
[Python Resources](https://www.w3schools.com/python/)</br>

Driver is *parse_temps_demo.py*</br>

## Sample output: </br>
times = []</br>
readings_core_0 = []</br>
readings_core_1 = []</br>
readings_core_2 = []</br>
readings_core_3 = []</br> </br>



Credit for parse_temps.py & parse_temps_demo.py files: https://github.com/cstkennedy/cs417-examples/tree/master/SemesterProject-CPU-Temps/python3 

