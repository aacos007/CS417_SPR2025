import os

#f(x) = = time, x_i = temps

def least_square_approximation(parse_temps, input_filename, output_dir = "output files"):
    #copied from previous itertion to extract data 
    # lists that will store parsed time values (list_of_times) & readings of CPU core temperatures (core_data)
    core_data = []
    list_of_times = []

    #extracts the plain filename without all the extra stuff/exetension after the period 
    basename = os.path.splitext(os.path.basename(input_filename))[0] 

    #loop that goes through a time values and creates a list of the core temps associated with that time
    for time, cores in parse_temps:
        list_of_times.append(time) #adds the time value to the time list
        if not core_data:
            core_data = [[] for _ in range(len(cores))] #creates an empty list for each CPU core (bascially like initalizing core_data with empty data)
        for i, temp in enumerate(cores):
            core_data[i].append(temp) #each temp is added to its corresponding core's list
    
    num_cores = len(core_data) #stores number of CPU cores
    n = len(list_of_times)

    #LSA math starts
    for core_idx in range(num_cores):
        sum_times = 0 #x
        sum_temps = 0 #y
        sum_times_squared = 0 #x^2
        sum_1 = 0 #number of points
        sum_xy = 0 #xy (time_temps * temperatures)

        #summation calculations
        for i in range(n):
            x = list_of_times[i]
            y = core_data[core_idx][i]
            sum_times += x
            sum_temps += y            
            sum_times_squared += x ** 2
            sum_xy += x * y
        
        #finding determinatns
        det = n * sum_times_squared - sum_times ** 2
        detX = sum_temps * sum_times_squared - sum_times * sum_xy
        detY = n * sum_xy - sum_times * sum_temps

        #compute c0 & c1...if statemnet steers clear of division by 0
        if det == 0:
            c0 = c1 = 0
        else:
            c0 = (detX)/det 
            c1 = (detY)/det 

        #writing to the output file
        output_file = os.path.join(output_dir, f"{basename}--core-{core_idx}.txt")
        with open(output_file, "a") as f:
            f.write(f"y={c0:.6f}+{c1:.6f}x; least-squares\n")


        """ #loop to iterate and go through each core
        for core_idx in range(num_cores):
            output_file = os.path.join(output_dir, f"{basename}--core-{core_idx}.txt") #creates the output file name
                            #{basefilename}-core-{core-number}.txt format
            with open(output_file, "w") as f: #opens the file so we can write in it
                for k in range(len(list_of_times) - 1):
                    x_k, x_k1 = list_of_times[k], list_of_times[k + 1] 
                    y_k, y_k1 = core_data[core_idx][k], core_data[core_idx][k + 1] 
                    
                    #calculate/update sums
                    sum_times += list_of_times[k]
                    sum_temps += core_data[core_idx][k]
                    sum_times_squared += list_of_times[k]**2
                    sum_1 += parse_temps.len(list_of_times)
                    sum_xy += list_of_times[k] * core_data[core_idx][k]

        #compute the determinants
        det = sum_1 * sum_times_squared - (sum_times)**2
        detX = sum_temps * sum_times_squared - sum_times * sum_xy
        detY = sum_1 * sum_xy - sum_temps * sum_times 

    #compute c0 & c1...if statemnet steers clear of division by 0
    if det == 0:
        c0 = c1 = 0
    else:
        c0 = (detX)/det 
        c1 = (detY)/det 


    #write to the file 
        f.write(f"{x_k}<=x<={x_k1}; y={c0:.6f}+{c1:.6f}x; least-squares\n")

    #print(f"Least squares approximation results saved in '{output_dir}' directory.") 
        

        """

    """
    def linear(times: list[float], core_temps: list[float]):
        
        T.B.W.

        Returns:
            one tuple in the form...

            (start time, end time, y-intercept, slope)
        

        start_time =
        end_time = 
        y_int = reading_end - (slope * time_end)
        slope = (reading_end - reading_start) / (time_end - time_start)

        return(start_time, end_time, y_int, slope)

        raise NotImplementedError() """

